import { useState, useEffect } from 'react';
import { CartItem, Product } from '../types';
import { storageService } from '../services/storage';

export const useCart = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadCart = () => {
      const savedCart = storageService.getCart();
      setCart(savedCart);
      setIsLoading(false);
    };

    loadCart();
  }, []);

  const addToCart = (product: Product, quantity: number = 1) => {
    storageService.addToCart(product, quantity);
    setCart(storageService.getCart());
  };

  const removeFromCart = (productId: string) => {
    storageService.removeFromCart(productId);
    setCart(storageService.getCart());
  };

  const updateQuantity = (productId: string, quantity: number) => {
    storageService.updateCartQuantity(productId, quantity);
    setCart(storageService.getCart());
  };

  const clearCart = () => {
    storageService.clearCart();
    setCart([]);
  };

  const getCartTotal = () => {
    return cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  };

  const getCartItemCount = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  return {
    cart,
    isLoading,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    getCartTotal,
    getCartItemCount
  };
};