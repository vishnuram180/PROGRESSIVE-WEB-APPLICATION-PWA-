import React from 'react';
import { Search, ShoppingCart, User, Menu, Wifi, WifiOff } from 'lucide-react';
import { usePWA } from '../hooks/usePWA';

interface HeaderProps {
  onSearchClick: () => void;
  onCartClick: () => void;
  onMenuClick: () => void;
  cartItemCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  onSearchClick,
  onCartClick,
  onMenuClick,
  cartItemCount
}) => {
  const { isOffline } = usePWA();

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-indigo-600">ShopSphere</h1>
            {isOffline && (
              <div className="ml-2 flex items-center text-amber-600">
                <WifiOff className="w-4 h-4 mr-1" />
                <span className="text-xs">Offline</span>
              </div>
            )}
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-4">
            <button
              onClick={onSearchClick}
              className="p-2 text-gray-600 hover:text-indigo-600 transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>
            <button
              onClick={onCartClick}
              className="p-2 text-gray-600 hover:text-indigo-600 transition-colors relative"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
            </button>
            <button className="p-2 text-gray-600 hover:text-indigo-600 transition-colors">
              <User className="w-5 h-5" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={onMenuClick}
              className="p-2 text-gray-600 hover:text-indigo-600 transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};