import { CartItem, User, Product } from '../types';

const STORAGE_KEYS = {
  CART: 'shopsphere-cart',
  USER: 'shopsphere-user',
  PRODUCTS: 'shopsphere-products-cache',
  CATEGORIES: 'shopsphere-categories-cache'
};

export const storageService = {
  // Cart management
  getCart(): CartItem[] {
    try {
      const cart = localStorage.getItem(STORAGE_KEYS.CART);
      return cart ? JSON.parse(cart) : [];
    } catch {
      return [];
    }
  },

  setCart(cart: CartItem[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
    } catch (error) {
      console.error('Failed to save cart:', error);
    }
  },

  addToCart(product: Product, quantity: number = 1): void {
    const cart = this.getCart();
    const existingItem = cart.find(item => item.product.id === product.id);
    
    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      cart.push({ id: product.id, product, quantity });
    }
    
    this.setCart(cart);
  },

  removeFromCart(productId: string): void {
    const cart = this.getCart();
    const updatedCart = cart.filter(item => item.product.id !== productId);
    this.setCart(updatedCart);
  },

  updateCartQuantity(productId: string, quantity: number): void {
    const cart = this.getCart();
    const item = cart.find(item => item.product.id === productId);
    
    if (item) {
      if (quantity <= 0) {
        this.removeFromCart(productId);
      } else {
        item.quantity = quantity;
        this.setCart(cart);
      }
    }
  },

  clearCart(): void {
    localStorage.removeItem(STORAGE_KEYS.CART);
  },

  // User management
  getUser(): User | null {
    try {
      const user = localStorage.getItem(STORAGE_KEYS.USER);
      return user ? JSON.parse(user) : null;
    } catch {
      return null;
    }
  },

  setUser(user: User): void {
    try {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
    } catch (error) {
      console.error('Failed to save user:', error);
    }
  },

  // Cache management
  cacheProducts(products: Product[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify({
        data: products,
        timestamp: Date.now()
      }));
    } catch (error) {
      console.error('Failed to cache products:', error);
    }
  },

  getCachedProducts(): Product[] | null {
    try {
      const cached = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      if (!cached) return null;
      
      const { data, timestamp } = JSON.parse(cached);
      const isExpired = Date.now() - timestamp > 30 * 60 * 1000; // 30 minutes
      
      return isExpired ? null : data;
    } catch {
      return null;
    }
  }
};