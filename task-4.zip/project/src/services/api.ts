import { Product, Category, User } from '../types';

const API_BASE = '/api';

// Mock data for development
const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Wireless Bluetooth Headphones',
    price: 199.99,
    originalPrice: 249.99,
    description: 'Premium wireless headphones with noise cancellation and 30-hour battery life.',
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Electronics',
    rating: 4.8,
    reviews: 324,
    inStock: true,
    featured: true
  },
  {
    id: '2',
    name: 'Smart Fitness Watch',
    price: 299.99,
    description: 'Track your fitness goals with this advanced smartwatch featuring heart rate monitoring.',
    image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Electronics',
    rating: 4.6,
    reviews: 189,
    inStock: true,
    featured: true
  },
  {
    id: '3',
    name: 'Organic Cotton T-Shirt',
    price: 29.99,
    description: 'Comfortable and sustainable organic cotton t-shirt in multiple colors.',
    image: 'https://images.pexels.com/photos/1183266/pexels-photo-1183266.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Clothing',
    rating: 4.4,
    reviews: 97,
    inStock: true
  },
  {
    id: '4',
    name: 'Minimalist Leather Wallet',
    price: 89.99,
    description: 'Handcrafted leather wallet with RFID protection and minimalist design.',
    image: 'https://images.pexels.com/photos/2693208/pexels-photo-2693208.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Accessories',
    rating: 4.7,
    reviews: 156,
    inStock: true
  },
  {
    id: '5',
    name: 'Ceramic Coffee Mug Set',
    price: 39.99,
    description: 'Beautiful set of 4 ceramic coffee mugs with elegant design.',
    image: 'https://images.pexels.com/photos/2074130/pexels-photo-2074130.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Home & Kitchen',
    rating: 4.5,
    reviews: 73,
    inStock: true
  },
  {
    id: '6',
    name: 'Yoga Mat Premium',
    price: 79.99,
    description: 'Non-slip yoga mat with extra thickness for comfort and stability.',
    image: 'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg?auto=compress&cs=tinysrgb&w=400',
    category: 'Sports',
    rating: 4.9,
    reviews: 241,
    inStock: true,
    featured: true
  }
];

const mockCategories: Category[] = [
  { id: '1', name: 'Electronics', icon: 'Smartphone', productCount: 45 },
  { id: '2', name: 'Clothing', icon: 'Shirt', productCount: 89 },
  { id: '3', name: 'Home & Kitchen', icon: 'Home', productCount: 67 },
  { id: '4', name: 'Sports', icon: 'Dumbbell', productCount: 34 },
  { id: '5', name: 'Accessories', icon: 'Watch', productCount: 23 }
];

const mockUser: User = {
  id: '1',
  name: 'John Doe',
  email: 'john@example.com',
  avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100'
};

// Simulate API delays and potential offline scenarios
const simulateNetworkDelay = (ms: number = 1000) => 
  new Promise(resolve => setTimeout(resolve, ms));

const isOnline = () => navigator.onLine;

export const apiService = {
  async getProducts(): Promise<Product[]> {
    await simulateNetworkDelay(500);
    if (!isOnline()) {
      throw new Error('Network unavailable');
    }
    return mockProducts;
  },

  async getProduct(id: string): Promise<Product | null> {
    await simulateNetworkDelay(300);
    if (!isOnline()) {
      throw new Error('Network unavailable');
    }
    return mockProducts.find(p => p.id === id) || null;
  },

  async getCategories(): Promise<Category[]> {
    await simulateNetworkDelay(200);
    if (!isOnline()) {
      throw new Error('Network unavailable');
    }
    return mockCategories;
  },

  async getUser(): Promise<User> {
    await simulateNetworkDelay(400);
    if (!isOnline()) {
      throw new Error('Network unavailable');
    }
    return mockUser;
  },

  async searchProducts(query: string): Promise<Product[]> {
    await simulateNetworkDelay(600);
    if (!isOnline()) {
      throw new Error('Network unavailable');
    }
    return mockProducts.filter(p => 
      p.name.toLowerCase().includes(query.toLowerCase()) ||
      p.description.toLowerCase().includes(query.toLowerCase())
    );
  }
};