import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ProductCard } from './components/ProductCard';
import { CartModal } from './components/CartModal';
import { SearchModal } from './components/SearchModal';
import { ProductModal } from './components/ProductModal';
import { BottomNav } from './components/BottomNav';
import { PWAPrompt } from './components/PWAPrompt';
import { LoadingSpinner } from './components/LoadingSpinner';
import { useCart } from './hooks/useCart';
import { usePWA } from './hooks/usePWA';
import { Product, Category } from './types';
import { apiService } from './services/api';
import { storageService } from './services/storage';

function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activeTab, setActiveTab] = useState('home');
  const [showCart, setShowCart] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showProduct, setShowProduct] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const { 
    cart, 
    addToCart, 
    removeFromCart, 
    updateQuantity, 
    clearCart, 
    getCartTotal, 
    getCartItemCount 
  } = useCart();

  const { isOffline, sendNotification } = usePWA();

  useEffect(() => {
    // Register service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then(registration => {
          console.log('SW registered:', registration);
        })
        .catch(error => {
          console.log('SW registration failed:', error);
        });
    }

    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      // Try to get cached data first
      const cachedProducts = storageService.getCachedProducts();
      
      if (cachedProducts) {
        setProducts(cachedProducts);
        setIsLoading(false);
      }

      // Fetch fresh data
      const [productsData, categoriesData] = await Promise.all([
        apiService.getProducts(),
        apiService.getCategories()
      ]);

      setProducts(productsData);
      setCategories(categoriesData);
      storageService.cacheProducts(productsData);
    } catch (error) {
      console.error('Failed to load data:', error);
      
      // Use cached data if available
      const cachedProducts = storageService.getCachedProducts();
      if (cachedProducts) {
        setProducts(cachedProducts);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddToCart = (product: Product) => {
    addToCart(product);
    sendNotification(`Added ${product.name} to cart`, {
      icon: '/icon-192.png',
      badge: '/icon-192.png'
    });
  };

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setShowProduct(true);
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    if (tab === 'search') {
      setShowSearch(true);
    } else if (tab === 'cart') {
      setShowCart(true);
    }
  };

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  const featuredProducts = products.filter(p => p.featured);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        onSearchClick={() => setShowSearch(true)}
        onCartClick={() => setShowCart(true)}
        onMenuClick={() => {}}
        cartItemCount={getCartItemCount()}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-20 md:pb-8">
        {isLoading ? (
          <LoadingSpinner />
        ) : (
          <>
            {/* Hero Section */}
            <section className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg p-8 mb-8">
              <div className="max-w-2xl">
                <h1 className="text-3xl md:text-4xl font-bold mb-4">
                  Welcome to ShopSphere
                </h1>
                <p className="text-lg text-indigo-100 mb-6">
                  Discover amazing products with our offline-first shopping experience
                </p>
                <button 
                  onClick={() => setShowSearch(true)}
                  className="bg-white text-indigo-600 px-6 py-3 rounded-lg font-medium hover:bg-indigo-50 transition-colors"
                >
                  Start Shopping
                </button>
              </div>
            </section>

            {/* Categories */}
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Categories</h2>
              <div className="flex space-x-4 overflow-x-auto pb-4">
                <button
                  onClick={() => setSelectedCategory('all')}
                  className={`flex-shrink-0 px-4 py-2 rounded-full transition-colors ${
                    selectedCategory === 'all' 
                      ? 'bg-indigo-600 text-white' 
                      : 'bg-white text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  All Products
                </button>
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.name)}
                    className={`flex-shrink-0 px-4 py-2 rounded-full transition-colors ${
                      selectedCategory === category.name
                        ? 'bg-indigo-600 text-white'
                        : 'bg-white text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    {category.name}
                  </button>
                ))}
              </div>
            </section>

            {/* Featured Products */}
            {featuredProducts.length > 0 && (
              <section className="mb-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Featured Products</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {featuredProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onAddToCart={handleAddToCart}
                      onProductClick={handleProductClick}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* Products Grid */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                {selectedCategory === 'all' ? 'All Products' : selectedCategory}
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={handleAddToCart}
                    onProductClick={handleProductClick}
                  />
                ))}
              </div>
            </section>
          </>
        )}
      </main>

      {/* Modals */}
      <CartModal
        isOpen={showCart}
        onClose={() => setShowCart(false)}
        cart={cart}
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeFromCart}
        onClearCart={clearCart}
        total={getCartTotal()}
      />

      <SearchModal
        isOpen={showSearch}
        onClose={() => setShowSearch(false)}
        onAddToCart={handleAddToCart}
        onProductClick={handleProductClick}
      />

      <ProductModal
        isOpen={showProduct}
        onClose={() => setShowProduct(false)}
        product={selectedProduct}
        onAddToCart={handleAddToCart}
      />

      {/* Mobile Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onTabChange={handleTabChange}
        cartItemCount={getCartItemCount()}
      />

      {/* PWA Prompts */}
      <PWAPrompt />
    </div>
  );
}

export default App;