import React from 'react';
import { Download, X, Bell } from 'lucide-react';
import { usePWA } from '../hooks/usePWA';

export const PWAPrompt: React.FC = () => {
  const { 
    isInstallable, 
    isInstalled, 
    notificationPermission, 
    installApp, 
    requestNotificationPermission 
  } = usePWA();

  const [showInstallPrompt, setShowInstallPrompt] = React.useState(false);
  const [showNotificationPrompt, setShowNotificationPrompt] = React.useState(false);

  React.useEffect(() => {
    if (isInstallable && !isInstalled) {
      const timer = setTimeout(() => setShowInstallPrompt(true), 3000);
      return () => clearTimeout(timer);
    }
  }, [isInstallable, isInstalled]);

  React.useEffect(() => {
    if (notificationPermission === 'default') {
      const timer = setTimeout(() => setShowNotificationPrompt(true), 5000);
      return () => clearTimeout(timer);
    }
  }, [notificationPermission]);

  const handleInstall = async () => {
    await installApp();
    setShowInstallPrompt(false);
  };

  const handleNotificationRequest = async () => {
    await requestNotificationPermission();
    setShowNotificationPrompt(false);
  };

  if (showInstallPrompt) {
    return (
      <div className="fixed bottom-4 left-4 right-4 bg-indigo-600 text-white p-4 rounded-lg shadow-lg z-50 md:max-w-md md:left-auto md:right-4">
        <div className="flex items-start space-x-3">
          <Download className="w-5 h-5 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <h3 className="font-semibold mb-1">Install ShopSphere</h3>
            <p className="text-sm text-indigo-100 mb-3">
              Install our app for a better shopping experience with offline access.
            </p>
            <div className="flex space-x-2">
              <button
                onClick={handleInstall}
                className="bg-white text-indigo-600 px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-50"
              >
                Install
              </button>
              <button
                onClick={() => setShowInstallPrompt(false)}
                className="text-indigo-100 hover:text-white text-sm"
              >
                Maybe later
              </button>
            </div>
          </div>
          <button
            onClick={() => setShowInstallPrompt(false)}
            className="text-indigo-100 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  }

  if (showNotificationPrompt) {
    return (
      <div className="fixed bottom-4 left-4 right-4 bg-emerald-600 text-white p-4 rounded-lg shadow-lg z-50 md:max-w-md md:left-auto md:right-4">
        <div className="flex items-start space-x-3">
          <Bell className="w-5 h-5 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <h3 className="font-semibold mb-1">Stay Updated</h3>
            <p className="text-sm text-emerald-100 mb-3">
              Get notified about new deals, order updates, and exclusive offers.
            </p>
            <div className="flex space-x-2">
              <button
                onClick={handleNotificationRequest}
                className="bg-white text-emerald-600 px-4 py-2 rounded-lg text-sm font-medium hover:bg-emerald-50"
              >
                Allow
              </button>
              <button
                onClick={() => setShowNotificationPrompt(false)}
                className="text-emerald-100 hover:text-white text-sm"
              >
                Not now
              </button>
            </div>
          </div>
          <button
            onClick={() => setShowNotificationPrompt(false)}
            className="text-emerald-100 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  }

  return null;
};